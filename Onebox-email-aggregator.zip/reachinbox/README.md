# ReachInbox - Project Zip (Starter)

This archive contains a starter backend and a minimal frontend for the ReachInbox assignment.

## Contents
- backend/: Node.js + TypeScript backend (IMAP IDLE skeleton, Elasticsearch indexing, heuristic AI categorization, Slack/webhook notifications, Express API)
- docker-compose.yml: Elasticsearch + Kibana
- README with run instructions

## Quick start

1. Unzip the project:
   ```bash
   unzip reachinbox_project.zip -d reachinbox
   cd reachinbox/backend
   ```

2. Start Elasticsearch:
   ```bash
   docker-compose up -d
   # wait ~30-60s for ES to be ready
   ```

3. Install backend deps:
   ```bash
   npm install
   ```

4. Copy .env.example -> .env and set any optional keys.

5. Run backend in dev:
   ```bash
   npx ts-node-dev --respawn --transpile-only src/index.ts
   ```

6. Use Postman or curl to test:
   - Create index (automatically created on startup)
   - POST /api/sync/start to start IMAP sync for accounts (see README in backend for sample body)
   - POST /api/search to search emails

Notes:
- The IMAP client needs valid IMAP credentials (e.g., Gmail app password) or you can use Mailtrap/MailHog for testing.
- The AI categorizer uses heuristics; you can set OPENAI_API_KEY in .env to enable model-based classification.
