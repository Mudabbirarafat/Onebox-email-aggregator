import axios from 'axios';

const SLACK_WEBHOOK = process.env.SLACK_WEBHOOK_URL;
const EXTERNAL_WEBHOOK = process.env.EXTERNAL_WEBHOOK_URL;

export async function notifyIfInterested(email: any) {
  const payload = {
    text: `*Interested* email detected\n*From:* ${email.from}\n*Subject:* ${email.subject}\n*Account:* ${email.account}`
  };

  try {
    if (SLACK_WEBHOOK) {
      await axios.post(SLACK_WEBHOOK, payload);
    }
  } catch (err) {
    console.error('Slack notify failed', err);
  }

  try {
    if (EXTERNAL_WEBHOOK) {
      await axios.post(EXTERNAL_WEBHOOK, { event: 'interested_email', email });
    }
  } catch (err) {
    console.error('External webhook failed', err);
  }
}
