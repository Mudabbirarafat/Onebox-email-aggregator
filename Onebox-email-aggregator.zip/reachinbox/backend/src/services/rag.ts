import axios from 'axios';
import { getEmailById } from './elastic';

const OPENAI_KEY = process.env.OPENAI_API_KEY;

export async function suggestReply(emailId?: string, email?: any): Promise<string> {
  try {
    let content = email?.body;
    let subject = email?.subject;
    if (emailId && !email) {
      const doc = await getEmailById(emailId);
      if (!doc) return 'Email not found';
      content = doc.body;
      subject = doc.subject;
    }

    if (!content) return 'No email content available';

    if (content.toLowerCase().includes('interview') || content.toLowerCase().includes('shortlist')) {
      return 'Thank you for shortlisting my profile! I am available for a technical interview. You can book a slot here: https://cal.com/example';
    }

    if (OPENAI_KEY) {
      const prompt = `You are an assistant that composes concise professional replies to emails using the following context.\n\nEmail Subject: ${subject}\nEmail Body: ${content}\n\nIf the email is indicating interest or scheduling, suggest a reply that includes a calendar link https://cal.com/example. Keep reply short (1-3 sentences).`;
      const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 100
      }, {
        headers: { Authorization: `Bearer ${OPENAI_KEY}` }
      });
      const reply = resp.data.choices?.[0]?.message?.content?.trim();
      return reply || 'No reply generated';
    }

    return 'Thanks for the update — I am available. Please use: https://cal.com/example to pick a slot.';
  } catch (err) {
    console.error('RAG suggest error', err);
    return 'Failed to generate suggestion';
  }
}
