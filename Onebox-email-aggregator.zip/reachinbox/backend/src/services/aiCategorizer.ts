import axios from 'axios';

const OPENAI_KEY = process.env.OPENAI_API_KEY;

export async function categorizeEmail(email: any): Promise<string | null> {
  const text = ((email.subject || '') + '\n' + (email.body || '')).toLowerCase();

  if (text.includes('out of office') || text.includes('on vacation') || text.includes('auto-reply')) {
    return 'Out of Office';
  }
  if (text.includes('unsubscribe') || text.includes('buy now') || text.includes('advertisement')) {
    return 'Spam';
  }
  if (text.includes('not interested') || text.includes('no thanks') || text.includes('no longer')) {
    return 'Not Interested';
  }
  if (text.includes('meeting booked') || text.includes('scheduled') || text.includes('confirmed') || text.includes('booked')) {
    return 'Meeting Booked';
  }
  if (text.includes('interested') || text.includes('sounds good') || text.includes('i would like') || text.includes('count me in')) {
    return 'Interested';
  }

  if (OPENAI_KEY) {
    try {
      const prompt = `Classify the following email into one of: Interested, Meeting Booked, Not Interested, Spam, Out of Office. Return only the label.\n\nSubject: ${email.subject}\n\nBody: ${email.body}\n\nLabel:`;
      const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-4o-mini',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 10
      }, {
        headers: {
          Authorization: `Bearer ${OPENAI_KEY}`
        }
      });
      const label = resp.data.choices?.[0]?.message?.content?.trim?.();
      if (label) return label.split('\n')[0].trim();
    } catch (err) {
      console.error('OpenAI categorization failed, falling back to heuristics', err);
    }
  }

  return null;
}
