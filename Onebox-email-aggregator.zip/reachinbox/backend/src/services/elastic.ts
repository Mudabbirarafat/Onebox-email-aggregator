import { Client } from '@elastic/elasticsearch';

const ELASTIC_URL = process.env.ELASTIC_URL || 'http://localhost:9200';
const es = new Client({ node: ELASTIC_URL });
const INDEX = 'emails';

export async function createEmailIndexIfNotExists() {
  try {
    const exists = await es.indices.exists({ index: INDEX });
    if (!exists) {
      await es.indices.create({
        index: INDEX,
        body: {
          mappings: {
            properties: {
              messageId: { type: 'keyword' },
              account: { type: 'keyword' },
              folder: { type: 'keyword' },
              from: { type: 'text' },
              to: { type: 'text' },
              subject: { type: 'text' },
              body: { type: 'text' },
              date: { type: 'date' },
              labels: { type: 'keyword' }
            }
          }
        }
      });
      console.log('Created index', INDEX);
    } else {
      console.log('Index exists', INDEX);
    }
  } catch (err) {
    console.error('Error creating index', err);
    throw err;
  }
}

export async function indexEmail(doc: any) {
  try {
    await es.index({
      index: INDEX,
      id: doc.messageId,
      document: doc,
      refresh: true
    });
  } catch (err) {
    console.error('ES index error', err);
  }
}

export async function searchEmails(q: string, filters: any = {}) {
  const mustAny = q ? [{ multi_match: { query: q, fields: ['subject', 'body', 'from', 'to'] } }] : [{ match_all: {} }];
  const filter = [];
  if (filters.account) filter.push({ term: { account: filters.account } });
  if (filters.folder) filter.push({ term: { folder: filters.folder } });
  if (filters.labels) filter.push({ term: { labels: filters.labels } });
  const body: any = {
    query: {
      bool: {
        must: mustAny,
        filter
      }
    },
    size: 50,
    sort: [{ date: { order: 'desc' } }]
  };
  const res = await es.search({ index: INDEX, body });
  return res.hits.hits.map((h: any) => h._source);
}

export async function getEmailById(id: string) {
  try {
    const resp = await es.get({ index: INDEX, id });
    return resp._source;
  } catch (err) {
    return null;
  }
}

export async function setLabel(id: string, label: string) {
  try {
    await es.update({
      index: INDEX,
      id,
      doc: { labels: [label] },
      refresh: true
    });
  } catch (err) {
    console.error('ES setLabel error', err);
  }
}
