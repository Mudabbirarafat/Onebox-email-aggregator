import { startImapAccount } from './imapClient';

const activeClients: Record<string, any> = {};

export async function startSyncForAccounts(accounts: any[]) {
  for (const acc of accounts) {
    try {
      if (activeClients[acc.accountId]) {
        console.log(`Account ${acc.accountId} already syncing`);
        continue;
      }
      const client = await startImapAccount(acc);
      activeClients[acc.accountId] = client;
      console.log(`Started IMAP sync for ${acc.accountId}`);
    } catch (err) {
      console.error(`Failed to start for ${acc.accountId}`, err);
    }
  }
}
