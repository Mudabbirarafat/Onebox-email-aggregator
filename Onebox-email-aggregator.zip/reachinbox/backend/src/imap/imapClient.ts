import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import { indexEmail } from '../services/elastic';
import { categorizeEmail } from '../services/aiCategorizer';
import { notifyIfInterested } from '../services/notifications';

export async function startImapAccount(account: any) {
  const client = new ImapFlow({
    host: account.host,
    port: account.port,
    secure: account.secure ?? true,
    auth: account.auth,
    logger: false
  });

  client.on('error', (err) => console.error('IMAP client error', err));

  await client.connect();
  console.log(`[${account.accountId}] connected to IMAP`);

  await client.mailboxOpen('INBOX');

  const since = new Date();
  since.setDate(since.getDate() - 30);

  try {
    for await (const msg of client.fetch({ since }, { source: true, internalDate: true })) {
      const parsed = await simpleParser(msg.source);
      const emailDoc: any = {
        messageId: parsed.messageId || parsed.headers.get('message-id') || `${account.accountId}-${Date.now()}`,
        account: account.accountId,
        folder: 'INBOX',
        from: parsed.from?.text || '',
        to: parsed.to?.text || '',
        subject: parsed.subject || '',
        body: parsed.text || parsed.html || '',
        date: parsed.date || msg.internalDate || new Date(),
        labels: []
      };
      await indexEmail(emailDoc);
      const label = await categorizeEmail(emailDoc);
      if (label) {
        emailDoc.labels = [label];
        await indexEmail(emailDoc);
      }
      if (label === 'Interested') {
        await notifyIfInterested(emailDoc);
      }
    }
  } catch (err) {
    console.error('initial fetch error', err);
  }

  client.on('exists', async () => {
    console.log(`[${account.accountId}] New message detected (exists event)`);
    try {
      for await (const msg of client.fetch('1:*', { source: true, internalDate: true })) {
        const parsed = await simpleParser(msg.source);
        const emailDoc: any = {
          messageId: parsed.messageId || parsed.headers.get('message-id') || `${account.accountId}-${Date.now()}`,
          account: account.accountId,
          folder: 'INBOX',
          from: parsed.from?.text || '',
          to: parsed.to?.text || '',
          subject: parsed.subject || '',
          body: parsed.text || parsed.html || '',
          date: parsed.date || msg.internalDate || new Date(),
          labels: []
        };
        await indexEmail(emailDoc);
        const label = await categorizeEmail(emailDoc);
        if (label) {
          emailDoc.labels = [label];
          await indexEmail(emailDoc);
        }
        if (label === 'Interested') {
          await notifyIfInterested(emailDoc);
        }
      }
    } catch (err) {
      console.error('Error handling exists event', err);
    }
  });

  return client;
}
