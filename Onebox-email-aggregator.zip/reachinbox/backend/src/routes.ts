import express from 'express';
import { startSyncForAccounts } from './imap/imapController';
import { searchEmails, getEmailById, setLabel } from './services/elastic';
import { suggestReply } from './services/rag';

const router = express.Router();

router.post('/sync/start', async (req, res) => {
  try {
    const { accounts } = req.body;
    if (!Array.isArray(accounts) || accounts.length === 0) return res.status(400).json({ error: 'accounts required' });
    await startSyncForAccounts(accounts);
    return res.json({ ok: true, started: accounts.length });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'failed' });
  }
});

router.post('/search', async (req, res) => {
  const { q = '', filters = {} } = req.body;
  try {
    const results = await searchEmails(q, filters);
    res.json({ results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'search failed' });
  }
});

router.get('/emails/:id', async (req, res) => {
  try {
    const doc = await getEmailById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'not found' });
    res.json({ email: doc });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'failed' });
  }
});

router.post('/emails/:id/label', async (req, res) => {
  try {
    const { label } = req.body;
    await setLabel(req.params.id, label);
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'failed' });
  }
});

router.post('/rag/suggest-reply', async (req, res) => {
  try {
    const { emailId, email } = req.body;
    const reply = await suggestReply(emailId, email);
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'RAG failed' });
  }
});

export default router;
