import express from 'express';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import { startSyncForAccounts } from './imap/imapController';
import { createEmailIndexIfNotExists } from './services/elastic';
import routes from './routes';

dotenv.config();
const app = express();
app.use(bodyParser.json());
app.use('/api', routes);

const PORT = process.env.PORT || 3000;

async function bootstrap() {
  console.log('Starting backend...');
  await createEmailIndexIfNotExists();
  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

bootstrap().catch(err => {
  console.error('Bootstrap error', err);
  process.exit(1);
});
