async function search(q) {
  const res = await fetch('/api/search', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ q, filters: {} })
  });
  return res.json();
}

document.getElementById('searchBtn').addEventListener('click', async () => {
  const q = document.getElementById('q').value;
  const data = await search(q);
  const root = document.getElementById('results');
  root.innerHTML = '';
  if (!data.results || data.results.length===0) {
    root.innerHTML = '<p>No results</p>';
    return;
  }
  for (const e of data.results) {
    const div = document.createElement('div');
    div.className = 'email';
    div.innerHTML = `<strong>${e.subject || '(no subject)'}</strong> <span class="label">${(e.labels||[]).join(', ')}</span>
      <div><em>From:</em> ${e.from}</div>
      <div>${(e.body||'').substring(0,300)}</div>`;
    root.appendChild(div);
  }
});
